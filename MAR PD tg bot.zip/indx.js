import { Telegraf } from "telegraf";
import dotenv from "dotenv";
import ms from "ms";

dotenv.config();
const bot = new Telegraf(process.env.BOT_TOKEN);

// util: only admins
async function requireAdmin(ctx, next) {
  const member = await ctx.getChatMember(ctx.from.id);
  if (["creator", "administrator"].includes(member.status)) return next();
  return ctx.reply("এই কমান্ডটা শুধু অ্যাডমিনরা চালাতে পারবে 🙏");
}

// parse target user (reply or @username)
function getTarget(ctx) {
  const replyId = ctx.message?.reply_to_message?.from?.id;
  const mention = ctx.message?.entities?.find(e => e.type === "text_mention");
  const text = ctx.message?.text || "";
  const usernameMatch = text.match(/@(\w+)/);
  return replyId || mention?.user?.id || usernameMatch?.[1] || null;
}

// welcome message
bot.on("new_chat_members", async (ctx) => {
  const names = ctx.message.new_chat_members.map(u => u.first_name).join(", ");
  await ctx.reply(`স্বাগতম, ${names}! 🎉 নিয়ম ভাঙলে মিউট/ব্যান হতে পারে—ভদ্র থাকুন।`);
});

// /kick
bot.command("kick", requireAdmin, async (ctx) => {
  const target = getTarget(ctx);
  if (!target) return ctx.reply("কাকে কিক করব? Reply বা @username দিন।");
  try {
    await ctx.kickChatMember(typeof target === "string" ? undefined : target, Math.floor(Date.now()/1000)+45);
    await ctx.unbanChatMember(typeof target === "string" ? undefined : target); // kick only
    ctx.reply("ব্যবহারকারীকে কিক করা হয়েছে ✅");
  } catch (e) { ctx.reply("কিক করতে পারলাম না—আমি কি অ্যাডমিন?"); }
});

// /ban
bot.command("ban", requireAdmin, async (ctx) => {
  const target = getTarget(ctx);
  if (!target) return ctx.reply("কাকে ব্যান করব? Reply বা @username দিন।");
  try {
    await ctx.kickChatMember(typeof target === "string" ? undefined : target);
    ctx.reply("ব্যবহারকারী ব্যান ✅");
  } catch { ctx.reply("ব্যান করতে পারলাম না—পারমিশন চেক করুন।"); }
});

// /unban
bot.command("unban", requireAdmin, async (ctx) => {
  const target = getTarget(ctx);
  if (!target) return ctx.reply("কাকে আনব্যান? Reply বা @username দিন।");
  try {
    await ctx.unbanChatMember(typeof target === "string" ? undefined : target);
    ctx.reply("আনব্যান ✅");
  } catch { ctx.reply("আনব্যান ব্যর্থ।"); }
});

// /mute
bot.command("mute", requireAdmin, async (ctx) => {
  const text = ctx.message.text.split(" ");
  const duration = text.find(t => /\d+(s|m|h|d)$/i.test(t)) || "10m";
  const target = getTarget(ctx);
  if (!target) return ctx.reply("কাকে মিউট? Reply বা @username দিন। উদাহরণ: /mute @user 10m");
  const until = Math.floor((Date.now() + ms(duration)) / 1000);
  try {
    await ctx.restrictChatMember(typeof target === "string" ? undefined : target, {
      until_date: until,
      permissions: {
        can_send_messages: false, can_send_media_messages: false,
        can_send_polls: false, can_add_web_page_previews: false,
        can_change_info: false, can_invite_users: false, can_pin_messages: false
      }
    });
    ctx.reply(`মিউট ✅ (${duration})`);
  } catch { ctx.reply("মিউট করতে পারলাম না—পারমিশন দিন।"); }
});

// /unmute
bot.command("unmute", requireAdmin, async (ctx) => {
  const target = getTarget(ctx);
  if (!target) return ctx.reply("কাকে আনমিউট? Reply বা @username দিন।");
  try {
    await ctx.restrictChatMember(typeof target === "string" ? undefined : target, {
      permissions: {
        can_send_messages: true, can_send_media_messages: true,
        can_send_polls: true, can_add_web_page_previews: true,
        can_change_info: false, can_invite_users: true, can_pin_messages: false
      }
    });
    ctx.reply("আনমিউট ✅");
  } catch { ctx.reply("আনমিউট ব্যর্থ।"); }
});

// warn system (in-memory)
const warns = new Map(); // key: userId, val: count

bot.command("warn", requireAdmin, async (ctx) => {
  const target = getTarget(ctx);
  const reason = ctx.message.text.split(" ").slice(2).join(" ") || "নিয়ম ভাঙা";
  if (!target) return ctx.reply("কাকে ওয়ার্ন? Reply বা @username দিন।");
  const id = typeof target === "string" ? target : target;
  const c = (warns.get(id) || 0) + 1;
  warns.set(id, c);
  await ctx.reply(`ওয়ার্ন দেওয়া হল (${c}/3) — কারণ: ${reason}`);
  if (c >= 3) {
    // auto mute 1h
    const until = Math.floor((Date.now() + ms("1h")) / 1000);
    try {
      await ctx.restrictChatMember(typeof target === "string" ? undefined : target, {
        until_date: until,
        permissions: { can_send_messages: false }
      });
      warns.set(id, 0);
      ctx.reply("৩ বার ওয়ার্নের পর 1h মিউট করা হল 🚫");
    } catch {}
  }
});

// help
bot.command("help", (ctx) => ctx.reply(
`কমান্ডসমূহ:
/kick @user
/ban @user
/unban @user
/mute @user 10m
/unmute @user
/warn @user [reason]
(Reply করেও কমান্ড চালাতে পারো)`
));

bot.launch();
console.log("Group manager bot running ✅");
process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));